const mongoose = require("mongoose");

//Create Schema
const userDataSchema = new mongoose.Schema(
  {
    id:{
        type: Number,
        required: true,
    },
    name: {
      type: String,
      required: true,
    },
    category : {
      type: String,
      required: true,
    },
    creatorName: {
      type: String,
    },
  },
  { timestamps: true }
);

//Create Model
const userData = mongoose.model("UserData", userDataSchema);

module.exports = userData;