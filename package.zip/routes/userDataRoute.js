const express = require("express");
const router = express.Router();
const userData = require("../models/userDataModel");

//CREATE
router.post("/", async (req, res) => {
  console.log(req.body);
  const { id, name, category, creatorName } = req.body;
  try {
    const userAdded = await userData.create({
        id:id,
        name: name,
        category: category,
        creatorName: creatorName,
    });
    res.status(201).json(userAdded);
  } catch (error) {
    console.log(error);
    res.status(400).json({ error: error.message });
  }
});



module.exports = router;