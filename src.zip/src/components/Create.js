import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Create = () => {
    const [id, setId] = useState(0);
    const [fname, setName] = useState("");
    const [category , setCategory ] = useState("");
    const [creatorName, setCreatorName] = useState("");
    const [error, setError] = useState("");

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        var addUser = {id, fname, category, creatorName };
        console.log(addUser);

        const response = await fetch("http://localhost:8000/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(addUser),
        });

        const result = await response.json();

        if (!response.ok) {
            console.log(result.error);
            setError(result.error);
        }
        if (response.ok) {
            console.log(result);
            setId(0);
            setName("");
            setCategory("");
            setCreatorName("");
            setError("");
            navigate("/read");
        }
    };

    return (
        <div class="container my-2">
            <h1 class="h1 text-center">Fill the data</h1>

            {error && <div class="alert alert-danger"> {error} </div>}
            <form className="form" onSubmit={handleSubmit}>
            <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input
                        type="text"
                        class="form-control"
                        value={id}
                        onChange={(e) => setName(e.target.value)}
                    />
                </div>
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input
                        type="text"
                        class="form-control"
                        value={fname}
                        onChange={(e) => setName(e.target.value)}
                    />
                </div>
                <div class="mb-3">
                    <label class="form-label">Email address</label>
                    <input
                        type="email"
                        class="form-control"
                        value={category}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>

                <div class="mb-3">
                    <label class="form-label">Email address</label>
                    <input
                        type="email"
                        class="form-control"
                        value={creatorName}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>
                <button type="submit" class="btn btn-primary">
                    Submit
                </button>
            </form>
        </div>
    );
};

export default Create;